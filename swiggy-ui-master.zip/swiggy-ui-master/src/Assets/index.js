import SwiggyLogo from "./SwiggyLogo.png";
import SwiggySymbol from "./SwiggySymbol.png";
import SwiggyLogoGray from "./SwiggyLogoGray.png";
import CartEmpty from "./CartEmpty.webp";
import CartEmpty2 from "./CartEmpty2.webp";
import PayByCash from "./PayByCash.webp";


export {
    SwiggyLogo, SwiggyLogoGray,
    SwiggySymbol, CartEmpty, PayByCash,
    CartEmpty2
};