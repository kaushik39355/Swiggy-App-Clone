const authTypes = {
    AUTH_LOGIN: "AUTH_LOGIN",
    AUTH_LOGOUT: "AUTH_LOGOUT",
    AUTH_PAGESET: "AUTH_PAGESET"
};

export default authTypes;