const notifiTypes = {
    NOTIFI_ADD: "NOTIFI_ADD",
    NOTIFI_REMOVE: "NOTIFI_REMOVE"
};

export default notifiTypes;