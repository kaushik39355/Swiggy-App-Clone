const preType = "LOCAL/";

const localTypes = {
    SET_LOCATION: preType + "SET_LOCATION",
    SET_PAGETITLE: preType + "SET_PAGETITLE",
    SET_ADDRESS: preType + "SET_ADDRESS",
    SET_CHECKOUTSTEP: preType + "SET_CHECKOUTSTEP",
    CARTITEM_ITEM: preType + "CARTITEM_ITEM",
}

export default localTypes;