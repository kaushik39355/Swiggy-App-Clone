const menuTypes = {
    SET_MENU_ACTIVE: "SET_MENU_ACTIVE"
};

export default menuTypes;